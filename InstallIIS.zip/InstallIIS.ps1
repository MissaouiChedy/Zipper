Configuration InstallIIS 
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    
    Node 'localhost'
    {
        WindowsFeature WebServerRole {
            Name   = "Web-Server"
            Ensure = "Present"
        }
    }
}