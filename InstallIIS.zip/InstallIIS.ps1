Configuration InstallIIS 
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DSCResource -ModuleName NetworkingDsc

    Node 'localhost'
    {
        WindowsFeature WebServerRole 
        {
            Name   = "Web-Server"
            Ensure = "Present"
        }

        Firewall AllowHttpPort80Rule
        {
            Name                  = 'Http_port_80'
            DisplayName           = 'Http port 80'
            Ensure                = 'Present'
            Enabled               = 'True'
            Action                = 'Allow'
            Profile               = 'Any'
            Direction             = 'InBound'
            LocalPort             = ('80')
            Protocol              = 'TCP'
        }
    }
}